<script>
	export default {
		//怎么进入的
		onLaunch: function(opation) {
			console.log('App Launch')
			console.log(opation);
		},
		//进来
		onShow: function() {
			console.log('App Show')
		},
		//离开
		onHide: function() {
			console.log('App Hide')
		}
	}
</script>

<style>
	/*每个页面公共css */
</style>
