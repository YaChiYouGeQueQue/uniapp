<template>
	<view class="content">
		<image class="logo" src="/static/logo.png"></image>
		<view class="text-area">
			<text class="title">{{title}}</text>
		</view>
		<!-- <button @click="topath()">新闻页</button> -->
		<button @click="topath">跳转测试页</button>
	</view>
</template>
	

<script>
	export default {
		data() {
			return {
				title: 'Hello ,Uniapp'
			}
		},
		onLoad() {

		},
		methods: {
			topath(){
				// 跳转[pages.json>tabBar]里已经配置过的页面用uni.switchTab
				// uni.switchTab({
				// 	url:"/pages/news/news"
				// })
				console.log("跳转向测试页");
				/* navigateTo打开新页面，保留老页面，一般用于返回Ps：老页面是有保留上限的，最多10个 */
				uni.navigateTo({
					url:"../test/test?name=guopeng"
				})
				// 随意跳转,无限制
				uni.uni.redirectTo({
					
				})
				
			}
		}
	}
	
</script>

<style>
	.content {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	}

	.logo {
		height: 200rpx;
		width: 200rpx;
		margin-top: 200rpx;
		margin-left: auto;
		margin-right: auto;
		margin-bottom: 50rpx;
	}

	.text-area {
		display: flex;
		justify-content: center;
	}

	.title {
		font-size: 36rpx;
		color: #8f8f94;
	}
</style>
