<template>
	<view>
		<text>{{news}}</text>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				news:"Hello,News"
			}
		},
		methods: {
			
		},
		onLoad() {
			console.log("页面初始化执行一次  onLoad");
		},
		onReady() {
			console.log("页面加载完毕，执行一次  onReady");
		},
		onHide() {
			console.log("页面离开执行多次，onHide")
		},
		onShow() {
			console.log("页面进入执行多次 onShow")
		},
		onPullDownRefresh() {
			console.log("用户执行了下拉");
		},
		
		onShareAppMessage() {
			console.log("用户执行了分享")
			return{
				title:"Hello,Uniapp",
				path:"pages/news/news",
				imageUrl:"https://www.baidu.com/img/baidu_jgylogo3.gif"	
			}
		}	
	}
</script>

<style lang="scss">

</style>
