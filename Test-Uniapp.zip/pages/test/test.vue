<template>
	<view>
		<text>{{title}}</text>
		<button @click="tolocal">返回原页面</button>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				title: 'Hello ,测试页面'
			}
		},
		onLoad(option) {
			console.log(option);
		},
		methods: {
			// 跳转[pages]里已经配置过的路径用uni.switchTab
			tolocal(){
				uni.navigateBack({
					delta:2
				})
			}
		}
	}
</script>

<style>
</style>
